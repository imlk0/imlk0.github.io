## easy_adb

这题我们拿到的是一个`.pcapng`格式的文件，用wireshark可以直接打开，发现是wireshark抓取的一系列的TCP包，分析内容后可以发现这是通过TCP建立的adb shell连接。

点击`Analyze`->`Follow TCP Stream`就可以看到TCP流信息：

![image-20201019120452409](image-20201019120452409.png)

我们只关注字符串部分，所有的`raw:`后面的内容都是shell执行的指令。一开始执行了一些echo语句打印欢迎语。之后出现了`getevent -lp`、`getevent -p`、、`getevent -l`、`getevent -t`四条和输入事件有关 的指令。

通过分析得知，插入了一个`Yubico Yubikey NEO OTP+U2F+CCID`设备，它通过模拟一个键盘向Android输入信息，键和事件ID表如下：

```
add device 1: /dev/input/event4
  name:     "Yubico Yubikey NEO OTP+U2F+CCID"
  events:
    KEY (0001): KEY_ESC               KEY_1                 KEY_2                 KEY_3                
                KEY_4                 KEY_5                 KEY_6                 KEY_7                
                KEY_8                 KEY_9                 KEY_0                 KEY_MINUS            
                KEY_EQUAL             KEY_BACKSPACE         KEY_TAB               KEY_Q                
                KEY_W                 KEY_E                 KEY_R                 KEY_T                
                KEY_Y                 KEY_U                 KEY_I                 KEY_O                
                KEY_P                 KEY_LEFTBRACE         KEY_RIGHTBRACE        KEY_ENTER            
                KEY_LEFTCTRL          KEY_A                 KEY_S                 KEY_D                
                KEY_F                 KEY_G                 KEY_H                 KEY_J                
                KEY_K                 KEY_L                 KEY_SEMICOLON         KEY_APOSTROPHE       
                KEY_GRAVE             KEY_LEFTSHIFT         KEY_BACKSLASH         KEY_Z                
                KEY_X                 KEY_C                 KEY_V                 KEY_B                
                KEY_N                 KEY_M                 KEY_COMMA             KEY_DOT              
                KEY_SLASH             KEY_RIGHTSHIFT        KEY_KPASTERISK        KEY_LEFTALT          
                KEY_SPACE             KEY_CAPSLOCK          KEY_F1                KEY_F2               
                KEY_F3                KEY_F4                KEY_F5                KEY_F6               
                KEY_F7                KEY_F8                KEY_F9                KEY_F10              
                KEY_NUMLOCK           KEY_SCROLLLOCK        KEY_KP7               KEY_KP8              
                KEY_KP9               KEY_KPMINUS           KEY_KP4               KEY_KP5              
                KEY_KP6               KEY_KPPLUS            KEY_KP1               KEY_KP2              
                KEY_KP3               KEY_KP0               KEY_KPDOT             KEY_102ND            
                KEY_F11               KEY_F12               KEY_KPENTER           KEY_RIGHTCTRL        
                KEY_KPSLASH           KEY_SYSRQ             KEY_RIGHTALT          KEY_HOME             
                KEY_UP                KEY_PAGEUP            KEY_LEFT              KEY_RIGHT            
                KEY_END               KEY_DOWN              KEY_PAGEDOWN          KEY_INSERT           
                KEY_DELETE            KEY_PAUSE             KEY_LEFTMETA          KEY_RIGHTMETA        
                KEY_COMPOSE          
    MSC (0004): MSC_SCAN             
    LED (0011): LED_NUML              LED_CAPSL             LED_SCROLLL           LED_COMPOSE          
                LED_KANA             
  input props:
    <none>
```

```
add device 1: /dev/input/event4
  name:     "Yubico Yubikey NEO OTP+U2F+CCID"
  events:
    KEY (0001): 0001  0002  0003  0004  0005  0006  0007  0008 
                0009  000a  000b  000c  000d  000e  000f  0010 
                0011  0012  0013  0014  0015  0016  0017  0018 
                0019  001a  001b  001c  001d  001e  001f  0020 
                0021  0022  0023  0024  0025  0026  0027  0028 
                0029  002a  002b  002c  002d  002e  002f  0030 
                0031  0032  0033  0034  0035  0036  0037  0038 
                0039  003a  003b  003c  003d  003e  003f  0040 
                0041  0042  0043  0044  0045  0046  0047  0048 
                0049  004a  004b  004c  004d  004e  004f  0050 
                0051  0052  0053  0056  0057  0058  0060  0061 
                0062  0063  0064  0066  0067  0068  0069  006a 
                006b  006c  006d  006e  006f  0077  007d  007e 
                007f 
    MSC (0004): 0004 
    LED (0011): 0000  0001  0002  0003  0004 
  input props:
    <none>
```

最后`getevent -t`命令按照时间顺序给出了期间该设备的输入信息，经过简单的处理，我们从中剥离出所有的输出，大概类似于这样：

```
[  269463.944942] 0014 0000 00000000
[  269463.944942] 0014 0001 00000000
[  269463.944942] 0000 0000 00000000
[  269463.952956] 0004 0004 00070019
[  269463.952956] 0001 002f 00000001
[  269463.952956] 0000 0000 00000000
[  269463.960909] 0004 0004 00070019
[  269463.960909] 0001 002f 00000000
...
```

通过在实机上测试我们发现，第一列是时间，第二列是事件id，第三列是事件的值，第四列是额外的参数，我们从中晒出第二列为`0001`的行（表示KEY事件），然后筛出第四列为`00000001`的行（表示按钮抬起的事件），取出第三列的事件id：

```
['002f','002f','0023','0020','0013','0014','0020','0020','0030','0031','002f','002f','0014','0026','0017','0012','0024','0020','0030','0022','0016','0031','0013','0017','002e','0017','0020','0024','0017','0016','002f','0023','0012','0021','0013','0020','0014','0017','0020','0026','0017','0024','0030','0013','001c']
```

再把上面的两个表做一个映射表出来，写一个python脚本去匹配这些id就能得到输入内容：

```python
ids_str = ['KEY_ESC','KEY_1','KEY_2','KEY_3','KEY_4','KEY_5','KEY_6','KEY_7','KEY_8','KEY_9','KEY_0','KEY_MINUS','KEY_EQUAL','KEY_BACKSPACE','KEY_TAB','KEY_Q','KEY_W','KEY_E','KEY_R','KEY_T','KEY_Y','KEY_U','KEY_I','KEY_O','KEY_P','KEY_LEFTBRACE','KEY_RIGHTBRACE','KEY_ENTER','KEY_LEFTCTRL','KEY_A','KEY_S','KEY_D','KEY_F','KEY_G','KEY_H','KEY_J','KEY_K','KEY_L','KEY_SEMICOLON','KEY_APOSTROPHE','KEY_GRAVE','KEY_LEFTSHIFT','KEY_BACKSLASH','KEY_Z','KEY_X','KEY_C','KEY_V','KEY_B','KEY_N','KEY_M','KEY_COMMA','KEY_DOT','KEY_SLASH','KEY_RIGHTSHIFT','KEY_KPASTERISK','KEY_LEFTALT','KEY_SPACE','KEY_CAPSLOCK','KEY_F1','KEY_F2','KEY_F3','KEY_F4','KEY_F5','KEY_F6','KEY_F7','KEY_F8','KEY_F9','KEY_F10','KEY_NUMLOCK','KEY_SCROLLLOCK','KEY_KP7','KEY_KP8','KEY_KP9','KEY_KPMINUS','KEY_KP4','KEY_KP5','KEY_KP6','KEY_KPPLUS','KEY_KP1','KEY_KP2','KEY_KP3','KEY_KP0','KEY_KPDOT','KEY_102ND','KEY_F11','KEY_F12','KEY_KPENTER','KEY_RIGHTCTRL','KEY_KPSLASH','KEY_SYSRQ','KEY_RIGHTALT','KEY_HOME','KEY_UP','KEY_PAGEUP','KEY_LEFT','KEY_RIGHT','KEY_END','KEY_DOWN','KEY_PAGEDOWN','KEY_INSERT','KEY_DELETE','KEY_PAUSE','KEY_LEFTMETA','KEY_RIGHTMETA','KEY_COMPOSE']
ids = ['0001','0002','0003','0004','0005','0006','0007','0008','0009','000a','000b','000c','000d','000e','000f','0010','0011','0012','0013','0014','0015','0016','0017','0018','0019','001a','001b','001c','001d','001e','001f','0020','0021','0022','0023','0024','0025','0026','0027','0028','0029','002a','002b','002c','002d','002e','002f','0030','0031','0032','0033','0034','0035','0036','0037','0038','0039','003a','003b','003c','003d','003e','003f','0040','0041','0042','0043','0044','0045','0046','0047','0048','0049','004a','004b','004c','004d','004e','004f','0050','0051','0052','0053','0056','0057','0058','0060','0061','0062','0063','0064','0066','0067','0068','0069','006a','006b','006c','006d','006e','006f','0077','007d','007e','007f']

ids_map = dict(zip(ids, ids_str))

input_ids = ['002f','002f','0023','0020','0013','0014','0020','0020','0030','0031','002f','002f','0014','0026','0017','0012','0024','0020','0030','0022','0016','0031','0013','0017','002e','0017','0020','0024','0017','0016','002f','0023','0012','0021','0013','0020','0014','0017','0020','0026','0017','0024','0030','0013','001c']

result = [ids_map[x][4:].lower() for x in input_ids]

print(result)

# output:
# ['v', 'v', 'h', 'd', 'r', 't', 'd', 'd', 'b', 'n', 'v', 'v', 't', 'l', 'i', 'e', 'j', 'd', 'b', 'g', 'u', 'n', 'r', 'i', 'c', 'i', 'd', 'j', 'i', 'u', 'v', 'h', 'e', 'f', 'r', 'd', 't', 'i', 'd', 'l', 'i', 'j', 'b', 'r', 'enter']

```

这是yubikey的OTP一次性密码。

分析一开始的欢迎语，其中有一条：

```
echo Your flag will be tsctf{*data*}
```

最后只要把输入内容套上`tsctf{` `}`就可以交了

