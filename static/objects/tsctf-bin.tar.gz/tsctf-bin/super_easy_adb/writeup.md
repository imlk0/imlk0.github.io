## super_easy_adb

这题我们拿到的依然是一个`.pcapng`格式的文件，老套路用wireshark可以直接打开，发现这次抓取的是USB协议的包，分析协议发现依然是adb shell。

这次没有像TCP包那样的选项让我们可以导出包的内容，不过我们可以直接用vscode打开这个二进制文件，直接看其中的字符串：

用`strings`命令可以提取出文件中的字符串内容：

```sh
strings -s '' -w ./super_easy_adb.pcapng
```

![image-20201019124706584](image-20201019124706584.png)



首先看`raw:`后面的内容，依然是`getevent -lp`、`getevent -p`、、`getevent -l`、`getevent -t`，但是这次的输入设备变成了`sec_touchscreen`，应该是一个触屏设备。

老规矩把映射表捞出来：

```
add device 2: /dev/input/event2
  name:     "sec_touchscreen"
  events:    KEY (0001): KEY_HOMEPAGE         OKAYyWRTE BTN_TOOL_FINGER       BTN_TOUCH             01c7                     
             ABS (0003): ABS_X                 : value 0, min 0, max 1439, fuzz 0, flat 0, resolution 0
                ABS_Y                 : value 0, min 0, max 2959, fuzz 0, flat 0, resolution 0
                ABS_PRESSURE          : value 0, min 0, max 63, fuzz 0, flat 0, resolution 0
                ABS_MT_SLOT           : value 0, min 0, max 9, fuzz 0, flat 0, resolution 0
                ABS_MT_TOUCH_MAJOR    : value 0, min 0, max 255, fuzz 0, flat 0, resolution 0
                ABS_MT_TOUCH_MINOR    : value 0, min 0, max 255, fuzz 0, flat 0, resolution 0
                ABS_MT_POSITION_X     : value 0, min 0, max 1439, fuzz 0, flat 0, resolution 0
                ABS_MT_POSITION_Y     : value 0, min 0, max 2959, fuzz 0, flat 0, resolution 0
                ABS_MT_TRACKING_ID    : value 0, min 0, max 65535, fuzz 0, flat 0, resolution 0
                ABS_MT_PRESSURE       : value 0, min 0, max 63, fuzz 0, flat 0, resolution 0
                003e                  : value 126, min 0, max 65535, fuzz 0, flat 0, resolution 0
             SW  (0005): SW_PEN_INSERTED        input props:    INPUT_PROP_DIRECT
```

```
add device 2: /dev/input/event2
  name:     "sec_touchscreen"
  events:
    KEY (0001): 00ac  0145  014a  01c7 
    ABS (0003): 0000  : value 0, min 0, max 1439, fuzz 0, flat 0, resolution 0
                0001  : value 0, min 0, max 2959, fuzz 0, flat 0, resolution 0
                0018  : value 0, min 0, max 63, fuzz 0, flat 0, resolution 0
                002f  : value 0, min 0, max 9, fuzz 0, flat 0, resolution 0
                0030  : value 0, min 0, max 255, fuzz 0, flat 0, resolution 0
                0031  : value 0, min 0, max 255, fuzz 0, flat 0, resolution 0
                0035  : value 0, min 0, max 1439, fuzz 0, flat 0, resolution 0
                0036  : value 0, min 0, max 2959, fuzz 0, flat 0, resolution 0
                0039  : value 0, min 0, max 65535, fuzz 0, flat 0, resolution 0
                003a  : value 0, min 0, max 63, fuzz 0, flat 0, resolution 0
                003e  : value 126, min 0, max 65535, fuzz 0, flat 0, resolution 0
    SW  (0005): 000f 
  input props:
    INPUT_PROP_DIRECT
```

这次我们只看`ABS (0003):`里的`ABS_MT_POSITION_X`和`ABS_MT_POSITION_Y`

比如下面这两条输出：第二列为`ABS (0003):`，第三列分别为`ABS_MT_POSITION_X`和`ABS_MT_POSITION_Y`，第三列的值则是屏幕像素点坐标。

```
[  270524.032103] 0003 0035 00000487
[  270524.032103] 0003 0036 000007b9
```

老规矩，写一个python脚本来解决这件事情

```python
import matplotlib.pyplot as plt

# input_strs太长了， 这里只放一部分
input_strs = '''[  270488.473135] 0003 0039 0000e822
[  270488.473135] 0001 014a 00000001
[  270488.473135] 0001 0145 00000001
[  270488.473135] 0003 0035 00000076
[  270488.473135] 0003 0036 0000025b
[  270488.473135] 0003 0030 0000000b
[  270488.473135] 0003 0031 0000000b
[  270488.473135] 0003 003a 00000007
[  270488.473135] 0000 0000 00000000
[  270488.497634] 0003 0030 0000000a
[  270488.497634] 0003 0031 0000000a
[  270488.497634] 0003 003a 00000006
[  270488.497634] 0000 0000 00000000
'''

cur_x = 0
cur_y = 0

xs = []
ys = []

for line in input_strs.split('\n'):
    if line[18:22] == '0003':
        if line[23:27] == '0035':
            cur_x = int(line[28:36], 16)
        if line[23:27] == '0036':
            cur_y = -int(line[28:36], 16) # 翻转
            xs.append(cur_x)
            ys.append(cur_y)

plt.scatter(xs, ys, alpha=0.6)
plt.show()
```

需要注意的是，与数学中的二位坐标不同，Android屏幕的坐标原点在屏幕左上角，因此y轴的方向是向下的，我们用一个负号来翻转图像。

![image-20201019130558172](image-20201019130558172.png)

屏幕手势的内容就是flag啦

